# Token Economy Plugin

This plugin provides a compact toolkit for reducing token usage when working in large codebases and configuration-heavy projects. It groups file search, text search, structured data extraction, and batch audit workflows into a single plugin.

## Features

This plugin includes the following features:

- **fd**: Find files and directories quickly from the command line instead of using recursive directory listing.
- **rg**: Search text content inside files with compact results instead of reading whole files.
- **jq**: Read, extract, filter, and transform JSON data with surgical precision.
- **yq**: Read, extract, filter, and transform YAML, TOML, and XML data.
- **xq**: Read and query XML content using `yq -p xml`.
- **structural-search**: Combine `fd` and `rg` to search both by file structure and by content.
- **batch-config-audit**: Combine `fd` with `jq`, `yq`, or `xq` to audit many configuration files in one pass.

## What It Optimizes

The goal of this plugin is to reduce the amount of terminal output and file content that must be loaded into context.

- Use `fd` when you need to find files by name, extension, or path.
- Use `rg` when you need to search for text inside files.
- Use `jq` when working with JSON.
- Use `yq` when working with YAML, TOML, or XML.
- Use `xq` when working with XML specifically.
- Use `structural-search` when you need both file location and content filtering.
- Use `batch-config-audit` when you need to extract the same field from many files.

## Typical Use Cases

- Find project files, pipelines, catalog entities, or configuration files.
- Search for references, annotations, imports, owners, or error patterns.
- Extract values from `package.json`, `pom.xml`, Backstage catalog files, or Kubernetes manifests.
- Audit many files at once without loading every file into context.

## Usage

The skills in this plugin are intended to be combined with the command line.

```bash
fd -e yaml . catalog/systems
rg "spec.owner" catalog/components
jq '.version' package.json
yq '.metadata.name' catalog/systems/sa-1242-osmose.yaml
```

For batch audits, chain file discovery with structured extraction:

```bash
fd -e yaml . catalog/systems -x yq '.metadata.name' {}
fd -g "pom.xml" . -x yq -p xml -oy '.project.version' {}
```

## Notes

- `fd` and `rg` are designed to respect `.gitignore` and keep output compact.
- `jq`, `yq`, and `xq` are most effective when you only need a few fields from each file.
- The `batch-config-audit` skill is the preferred pattern when you need the same field from many files.